import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const CandidateScreen = () => {
  return (
    <View>
      <Text>CandidateScreen</Text>
    </View>
  );
};

export default CandidateScreen;

const styles = StyleSheet.create({});
