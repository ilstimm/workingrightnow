import React from 'react';
import {StyleSheet, View, Text, Pressable} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import LoginScreen from './LoginScreen';
import CandidateScreen from './CandidateScreen';

const Stack = createStackNavigator();

function App() {
  return (
    // <LoginScreen></LoginScreen>
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="loginSreen" component={LoginScreen} />
        <Stack.Screen name="candidateScreen" component={CandidateScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  body: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    fontSize: 40,
    fontWeight: 'bold',
    margin: 10,
  },
});

export default App;
